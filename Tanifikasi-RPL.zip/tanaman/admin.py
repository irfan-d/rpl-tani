from django.contrib import admin
from .models import Tumbuhan

admin.site.register(Tumbuhan)
# Register your models here.
