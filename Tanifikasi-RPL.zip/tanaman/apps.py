from django.apps import AppConfig


class TanamanConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tanaman'
    