from django.contrib import admin
from .models import Attendances

# Register your models here.
admin.site.register(Attendances)
# Register your models here.
